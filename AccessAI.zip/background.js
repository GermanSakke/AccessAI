// Background script for AccessAI Chrome Extension

// Handle extension installation
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        console.log('AccessAI extension installed');
        
        // Set default settings
        chrome.storage.sync.set({
            altTextEnabled: false,
            summarizeEnabled: false,
            voiceNavEnabled: false,
            summarizationLevel: 'short',
            apiEndpoint: 'http://localhost:8000',
            openaiKey: ''
        });
    }
});

// Handle messages from content scripts and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
        case 'GET_SETTINGS':
            chrome.storage.sync.get(null, (settings) => {
                sendResponse(settings);
            });
            return true; // Keep message channel open
            
        case 'SAVE_SETTINGS':
            chrome.storage.sync.set(message.settings, () => {
                sendResponse({ success: true });
            });
            return true;
            
        default:
            sendResponse({ success: false, error: 'Unknown message type' });
    }
});

// Handle tab updates to inject content script if needed
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        // Check if content script needs to be injected
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: ['content.js']
        }).catch((error) => {
            // Ignore errors for chrome:// pages and other restricted URLs
            console.log('Could not inject content script:', error);
        });
    }
});
