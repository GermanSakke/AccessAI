// Popup script for AccessAI Chrome Extension

class AccessAIPopup {
    constructor() {
        this.initializeElements();
        this.loadSettings();
        this.setupEventListeners();
        this.updateStatus('Ready', 'ready');
    }

    initializeElements() {
        // Toggle switches
        this.altTextToggle = document.getElementById('altTextToggle');
        this.summarizeToggle = document.getElementById('summarizeToggle');
        this.voiceNavToggle = document.getElementById('voiceNavToggle');
        
        // Settings
        this.settingsPanel = document.getElementById('settingsPanel');
        this.settingsBtn = document.getElementById('settingsBtn');
        this.summarizationLevel = document.getElementById('summarizationLevel');
        this.apiEndpoint = document.getElementById('apiEndpoint');
        this.openaiKey = document.getElementById('openaiKey');
        
        // Controls
        this.analyzeBtn = document.getElementById('analyzeBtn');
        this.voiceBtn = document.getElementById('voiceBtn');
        this.voiceControls = document.getElementById('voiceControls');
        this.voiceStatus = document.getElementById('voiceStatus');
        
        // Status
        this.statusIndicator = document.getElementById('statusIndicator');
        this.statusText = document.getElementById('statusText');
    }

    setupEventListeners() {
        // Toggle switches
        this.altTextToggle.addEventListener('change', () => this.saveSettings());
        this.summarizeToggle.addEventListener('change', () => this.saveSettings());
        this.voiceNavToggle.addEventListener('change', () => this.toggleVoiceControls());
        
        // Settings
        this.settingsBtn.addEventListener('click', () => this.toggleSettings());
        this.summarizationLevel.addEventListener('change', () => this.saveSettings());
        this.apiEndpoint.addEventListener('change', () => this.saveSettings());
        this.openaiKey.addEventListener('change', () => this.saveSettings());
        
        // Controls
        this.analyzeBtn.addEventListener('click', () => this.analyzeCurrentPage());
        this.voiceBtn.addEventListener('click', () => this.toggleVoiceRecognition());
    }

    async loadSettings() {
        try {
            const result = await chrome.storage.sync.get({
                altTextEnabled: false,
                summarizeEnabled: false,
                voiceNavEnabled: false,
                summarizationLevel: 'short',
                apiEndpoint: 'http://localhost:8000',
                openaiKey: ''
            });

            this.altTextToggle.checked = result.altTextEnabled;
            this.summarizeToggle.checked = result.summarizeEnabled;
            this.voiceNavToggle.checked = result.voiceNavEnabled;
            this.summarizationLevel.value = result.summarizationLevel;
            this.apiEndpoint.value = result.apiEndpoint;
            this.openaiKey.value = result.openaiKey;

            this.toggleVoiceControls();
        } catch (error) {
            console.error('Error loading settings:', error);
            this.updateStatus('Error loading settings', 'error');
        }
    }

    async saveSettings() {
        try {
            const settings = {
                altTextEnabled: this.altTextToggle.checked,
                summarizeEnabled: this.summarizeToggle.checked,
                voiceNavEnabled: this.voiceNavToggle.checked,
                summarizationLevel: this.summarizationLevel.value,
                apiEndpoint: this.apiEndpoint.value,
                openaiKey: this.openaiKey.value
            };

            await chrome.storage.sync.set(settings);
            
            // Send settings to content script
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab.id) {
                chrome.tabs.sendMessage(tab.id, {
                    type: 'UPDATE_SETTINGS',
                    settings: settings
                });
            }
            
            this.updateStatus('Settings saved', 'ready');
        } catch (error) {
            console.error('Error saving settings:', error);
            this.updateStatus('Error saving settings', 'error');
        }
    }

    toggleSettings() {
        const isVisible = this.settingsPanel.style.display !== 'none';
        this.settingsPanel.style.display = isVisible ? 'none' : 'block';
        this.settingsBtn.textContent = isVisible ? 'Settings' : 'Hide Settings';
    }

    toggleVoiceControls() {
        const isEnabled = this.voiceNavToggle.checked;
        this.voiceControls.style.display = isEnabled ? 'block' : 'none';
        this.saveSettings();
    }

    async analyzeCurrentPage() {
        try {
            this.updateStatus('Analyzing page...', 'processing');
            
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab.id) {
                throw new Error('No active tab found');
            }

            // Send analysis command to content script
            const response = await chrome.tabs.sendMessage(tab.id, {
                type: 'ANALYZE_PAGE'
            });

            if (response && response.success) {
                this.updateStatus('Analysis complete', 'ready');
            } else {
                throw new Error(response?.error || 'Analysis failed');
            }
        } catch (error) {
            console.error('Error analyzing page:', error);
            this.updateStatus('Analysis failed', 'error');
        }
    }

    toggleVoiceRecognition() {
        if (this.isListening) {
            this.stopVoiceRecognition();
        } else {
            this.startVoiceRecognition();
        }
    }

    async startVoiceRecognition() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab.id) {
                throw new Error('No active tab found');
            }
            await chrome.tabs.sendMessage(tab.id, { type: 'VOICE_START' });
            this.isListening = true;
            this.voiceBtn.textContent = '🛑 Stop Voice';
            this.voiceBtn.classList.add('listening');
            this.voiceStatus.textContent = 'Listening...';
            this.updateStatus('Voice recognition active', 'processing');
        } catch (error) {
            console.error('Error starting voice recognition:', error);
            this.updateStatus('Unable to start voice on this page', 'error');
        }
    }

    async stopVoiceRecognition() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab.id) {
                await chrome.tabs.sendMessage(tab.id, { type: 'VOICE_STOP' });
            }
        } catch {}
        this.isListening = false;
        this.voiceBtn.textContent = '🎤 Start Voice';
        this.voiceBtn.classList.remove('listening');
        this.voiceStatus.textContent = 'Click to start voice commands';
    }

    async processVoiceCommand(command) {
        try {
            this.updateStatus('Processing voice command...', 'processing');
            
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab.id) {
                throw new Error('No active tab found');
            }

            // Send voice command to content script
            const response = await chrome.tabs.sendMessage(tab.id, {
                type: 'VOICE_COMMAND',
                command: command
            });

            if (response && response.success) {
                this.updateStatus('Voice command executed', 'ready');
            } else {
                throw new Error(response?.error || 'Voice command failed');
            }
        } catch (error) {
            console.error('Error processing voice command:', error);
            this.updateStatus('Voice command failed', 'error');
        }
    }

    updateStatus(message, type = 'ready') {
        this.statusText.textContent = message;
        this.statusIndicator.className = `status-indicator ${type}`;
        
        // Auto-clear status after 3 seconds for non-error messages
        if (type !== 'error') {
            setTimeout(() => {
                if (this.statusText.textContent === message) {
                    this.updateStatus('Ready', 'ready');
                }
            }, 3000);
        }
    }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new AccessAIPopup();
});
