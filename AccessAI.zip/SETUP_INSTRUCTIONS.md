# AccessAI Setup Instructions

## Current Issue
Your system needs Xcode command line tools to run Python. Here's how to fix this:

## Option 1: Install Xcode Command Line Tools (Recommended)

```bash
# Install Xcode command line tools
xcode-select --install
```

This will open a dialog asking you to install the tools. Click "Install" and wait for the installation to complete.

## Option 2: Alternative Python Installation

If you prefer not to install Xcode tools, you can use Homebrew to install Python:

```bash
# Install Homebrew (if not already installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Python via Homebrew
brew install python
```

## After Installing Python

Once Python is working, you can start the backend:

```bash
# Method 1: Use the startup script
./start_backend.sh

# Method 2: Manual startup
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python main.py
```

## Install Tesseract OCR (Required for Image Processing)

```bash
# Install Tesseract
brew install tesseract

# Verify installation
tesseract --version
```

## Test the Backend

Once running, test the API:

```bash
# Health check
curl http://localhost:8000/

# API documentation
open http://localhost:8000/docs
```

## Install the Chrome Extension

1. Open Chrome and go to `chrome://extensions/`
2. Enable "Developer mode" (toggle in top-right)
3. Click "Load unpacked"
4. Select the `AccessAI` folder
5. The AccessAI icon should appear in your toolbar

## Test the Extension

1. Open the demo page: `file:///Users/dario/AccessAI/demo.html`
2. Click the AccessAI icon
3. Enable all features
4. Click "Analyze Current Page"
5. Try voice commands like "click 1", "scroll down"

## Expected Results

- ✅ Green overlays with alt text for images
- ✅ Summary panel in top-right corner
- ✅ Red numbered circles on interactive elements
- ✅ Voice navigation working
- ✅ Audio feedback for actions

## Troubleshooting

**Backend won't start:**
- Ensure Python 3.7+ is installed
- Install Tesseract OCR
- Check that port 8000 is available

**Extension not working:**
- Verify backend is running on http://localhost:8000
- Check browser console for errors
- Ensure microphone permissions are granted

**Voice recognition issues:**
- Check microphone permissions in Chrome
- Try refreshing the page
- Ensure you're on a secure context (https:// or localhost)

## Next Steps

1. Install Xcode command line tools or Python via Homebrew
2. Install Tesseract OCR
3. Start the backend server
4. Load the Chrome extension
5. Test on the demo page or news sites

The AccessAI extension is fully built and ready to use once the Python environment is set up!
