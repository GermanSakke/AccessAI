# AccessAI Installation Guide

## Quick Start

### 1. Start the Backend Server

```bash
# From the AccessAI directory
./start_backend.sh
```

This script will:
- Create a Python virtual environment
- Install all required dependencies
- Check for Tesseract OCR installation
- Start the FastAPI server on `http://localhost:8000`

### 2. Install the Chrome Extension

1. Open Chrome and navigate to `c/`hrome://extensions
2. Enable "Developer mode" (toggle in top-right corner)
3. Click "Load unpacked"
4. Select the `AccessAI` folder (the one containing `manifest.json`)
5. The AccessAI icon should appear in your Chrome toolbar

### 3. Test the Extension

1. Open the demo page: `file:///path/to/AccessAI/demo.html`
2. Click the AccessAI icon in your toolbar
3. Enable all features (Alt Text, Summarization, Voice Navigation)
4. Click "Analyze Current Page"
5. Try voice commands like "click 1", "scroll down"

## Detailed Installation

### Backend Requirements

**Python 3.7+**
```bash
# Check Python version
python3 --version
```

**Tesseract OCR (for image processing fallback)**
```bash
# macOS
brew install tesseract

# Ubuntu/Debian
sudo apt-get install tesseract-ocr

# Windows
# Download from: https://github.com/UB-Mannheim/tesseract/wiki
```

**Python Dependencies**
```bash
cd backend
pip install -r requirements.txt
```

### Extension Requirements

- Chrome browser (Manifest V3 support)
- Microphone access (for voice navigation)
- Internet connection (for OpenAI API, optional)

## Configuration

### OpenAI API Key (Optional)

For enhanced features, get an API key from [OpenAI](https://platform.openai.com/api-keys):

1. Click the AccessAI extension icon
2. Click "Settings"
3. Enter your OpenAI API key
4. Click outside the field to save

**Features with OpenAI:**
- Better image descriptions using GPT-4 Vision
- Improved text summarization using GPT-3.5
- More accurate voice command processing

**Features without OpenAI:**
- Basic image descriptions using Tesseract OCR
- Simple text summarization
- Basic voice command processing

## Testing

### Test on Demo Page

1. Open `demo.html` in Chrome
2. Enable all AccessAI features
3. Click "Analyze Current Page"
4. Verify:
   - Images get green alt text overlays
   - Summary panel appears in top-right
   - Interactive elements get numbered red circles
   - Voice commands work

### Test on Real Websites

Try these news sites:
- BBC News: `https://www.bbc.com/news`
- CNN: `https://www.cnn.com`
- New York Times: `https://www.nytimes.com`

**Expected behavior:**
- Images without alt text get descriptions
- Page content gets summarized
- Navigation elements get numbered for voice control

## Troubleshooting

### Backend Issues

**Server won't start:**
```bash
# Check if port 8000 is in use
lsof -i :8000

# Kill process if needed
kill -9 <PID>
```

**Python dependencies error:**
```bash
cd backend
pip install --upgrade pip
pip install -r requirements.txt
```

**Tesseract not found:**
```bash
# macOS
brew install tesseract

# Check installation
tesseract --version
```

### Extension Issues

**Extension not loading:**
- Check that `manifest.json` is in the root directory
- Ensure all files are present (popup.html, content.js, etc.)
- Check Chrome console for errors

**Features not working:**
- Verify backend server is running on `http://localhost:8000`
- Check browser console for API errors
- Ensure microphone permissions are granted

**Voice recognition not working:**
- Check microphone permissions in Chrome
- Try refreshing the page
- Ensure you're on a secure context (https:// or localhost)

### API Issues

**OpenAI API errors:**
- Verify API key is correct
- Check API key has sufficient credits
- Ensure API key has access to GPT-4 Vision (for image descriptions)

**CORS errors:**
- Backend is configured to allow all origins for development
- In production, update CORS settings in `backend/main.py`

## Development

### Running in Development Mode

**Backend:**
```bash
cd backend
python main.py
# Server runs with auto-reload on file changes
```

**Extension:**
- Load as unpacked extension in Chrome
- Changes to files require extension reload in `chrome://extensions/`

### File Structure

```
AccessAI/
├── manifest.json          # Extension configuration
├── popup.html             # Extension popup UI
├── popup.css              # Popup styles
├── popup.js               # Popup logic
├── content.js             # Content script (runs on websites)
├── content.css            # Content script styles
├── background.js          # Background service worker
├── icons/                 # Extension icons
├── backend/               # FastAPI backend
│   ├── main.py           # API server
│   ├── requirements.txt  # Python dependencies
│   └── README.md         # Backend documentation
├── demo.html             # Test page
├── start_backend.sh      # Backend startup script
└── README.md             # Main documentation
```

## Production Deployment

### Backend Deployment

1. Set up a production server (AWS, GCP, etc.)
2. Install Python and dependencies
3. Configure CORS for your domain
4. Set up SSL certificate
5. Use a production WSGI server (Gunicorn)

### Extension Distribution

1. Create a Chrome Web Store developer account
2. Package the extension (zip the files)
3. Upload to Chrome Web Store
4. Configure store listing and permissions

## Support

For issues:
1. Check this troubleshooting guide
2. Review browser console for errors
3. Check backend server logs
4. Ensure all dependencies are installed
5. Create an issue with detailed error information
