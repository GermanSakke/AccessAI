#!/bin/bash

# AccessAI Backend Startup Script

echo "🚀 Starting AccessAI Backend Server..."
echo "=================================="

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3 first."
    exit 1
fi

# Check if we're in the right directory
if [ ! -f "backend/main.py" ]; then
    echo "❌ Please run this script from the AccessAI root directory."
    echo "   Current directory: $(pwd)"
    exit 1
fi

# Navigate to backend directory
cd backend

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Install dependencies
echo "📥 Installing dependencies..."
pip install -r requirements.txt

# Check if Tesseract is installed
if ! command -v tesseract &> /dev/null; then
    echo "⚠️  Tesseract OCR is not installed."
    echo "   Install it with:"
    echo "   - macOS: brew install tesseract"
    echo "   - Ubuntu/Debian: sudo apt-get install tesseract-ocr"
    echo "   - Windows: Download from https://github.com/UB-Mannheim/tesseract/wiki"
    echo ""
    echo "   The extension will still work with OpenAI API, but image processing will be limited."
    echo ""
fi

# Start the server
echo "🌐 Starting FastAPI server on http://localhost:8000"
echo "   Press Ctrl+C to stop the server"
echo "   API documentation available at http://localhost:8000/docs"
echo ""

python main.py
