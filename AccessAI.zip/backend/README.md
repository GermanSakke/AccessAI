# AccessAI Backend API

FastAPI backend server for the AccessAI Chrome extension.

## Features

- **Image Description**: Generate alt text for images using OpenAI Vision API or Tesseract OCR
- **Text Summarization**: Summarize web page content using OpenAI GPT or simple text processing
- **Voice Command Processing**: Process voice commands for navigation assistance

## Installation

1. Install Python dependencies:
```bash
pip install -r requirements.txt
```

2. Install Tesseract OCR:
   - **macOS**: `brew install tesseract`
   - **Ubuntu/Debian**: `sudo apt-get install tesseract-ocr`
   - **Windows**: Download from [GitHub](https://github.com/UB-Mannheim/tesseract/wiki)

3. (Optional) Set up OpenAI API key:
   - Get an API key from [OpenAI](https://platform.openai.com/api-keys)
   - The extension will prompt for the key in the settings

## Running the Server

```bash
python main.py
```

The server will start on `http://localhost:8000`

## API Endpoints

### GET /
Health check endpoint

### POST /describe_image
Generate alt text for an image

**Request:**
```json
{
  "image": "data:image/jpeg;base64,/9j/4AAQ...",
  "openai_key": "sk-..." // optional
}
```

**Response:**
```json
{
  "description": "A photo of a cat sitting on a windowsill",
  "method": "openai"
}
```

### POST /summarize_text
Summarize text content

**Request:**
```json
{
  "text": "Long article text...",
  "level": "short", // or "detailed"
  "openai_key": "sk-..." // optional
}
```

**Response:**
```json
{
  "summary": "This article discusses...",
  "original_length": 5000,
  "summary_length": 200
}
```

### POST /voice_command
Process voice commands

**Request:**
```json
{
  "command": "click 5",
  "context": {} // optional
}
```

**Response:**
```json
{
  "action": "click_element",
  "success": true,
  "message": "Clicking element 5"
}
```

## Development

The API includes automatic fallbacks:
- If OpenAI API fails, it falls back to Tesseract OCR for images
- If OpenAI API fails, it falls back to simple text summarization
- All endpoints work without OpenAI API keys (with reduced functionality)

## CORS

The API is configured to allow requests from any origin for development. In production, you should restrict this to your specific domains.
