"""
AccessAI Backend API
FastAPI server for AI-powered accessibility features
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import base64
import io
import os
import requests
from PIL import Image
import pytesseract
from typing import Optional
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="AccessAI API",
    description="AI-powered accessibility enhancement backend",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request models
class ImageDescriptionRequest(BaseModel):
    image: Optional[str] = None  # Base64 encoded image (optional)
    image_url: Optional[str] = None  # Direct image URL (optional)
    openai_key: Optional[str] = None

class TextSummaryRequest(BaseModel):
    text: str
    level: str = "short"  # "short" or "detailed"
    openai_key: Optional[str] = None

class VoiceCommandRequest(BaseModel):
    command: str
    context: Optional[dict] = None

# Response models
class ImageDescriptionResponse(BaseModel):
    description: str
    method: str  # "openai" or "tesseract"

class TextSummaryResponse(BaseModel):
    summary: str
    original_length: int
    summary_length: int

class VoiceCommandResponse(BaseModel):
    action: str
    success: bool
    message: str

def get_openai_client(api_key: str):
    """Get OpenAI client with API key"""
    try:
        import openai
        return openai.OpenAI(api_key=api_key)
    except ImportError:
        logger.warning("OpenAI library not installed. Install with: pip install openai")
        return None

def describe_image_with_openai(image_data: str, api_key: str) -> str:
    """Describe image using OpenAI Vision API"""
    try:
        client = get_openai_client(api_key)
        if not client:
            raise Exception("OpenAI client not available")
        
        # Remove data URL prefix if present
        if image_data.startswith('data:image'):
            image_data = image_data.split(',')[1]
        
        response = client.chat.completions.create(
            model="gpt-4-vision-preview",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": "Describe this image in detail for accessibility purposes. Focus on important visual elements, text content, and context that would help someone who cannot see the image understand what it contains."
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{image_data}"
                            }
                        }
                    ]
                }
            ],
            max_tokens=300
        )
        
        return response.choices[0].message.content
    except Exception as e:
        logger.error(f"OpenAI image description error: {e}")
        raise Exception(f"OpenAI API error: {str(e)}")

def describe_image_with_tesseract(image_data: str) -> str:
    """Describe image using Tesseract OCR as fallback"""
    try:
        # Remove data URL prefix if present
        if image_data.startswith('data:image'):
            image_data = image_data.split(',')[1]
        
        # Decode base64 image
        image_bytes = base64.b64decode(image_data)
        image = Image.open(io.BytesIO(image_bytes))
        
        # Extract text using OCR
        text = pytesseract.image_to_string(image)
        
        if text.strip():
            return f"Image contains text: {text.strip()}"
        else:
            return "Image appears to be decorative or contains no readable text"
    except Exception as e:
        logger.error(f"Tesseract OCR error: {e}")
        return "Unable to process image"

def fetch_image_as_base64(image_url: str) -> str:
    """Fetch image from URL and return base64-encoded JPEG data string (without data URL prefix)."""
    try:
        response = requests.get(image_url, timeout=15)
        response.raise_for_status()
        image = Image.open(io.BytesIO(response.content)).convert("RGB")
        buffer = io.BytesIO()
        image.save(buffer, format="JPEG", quality=85)
        return base64.b64encode(buffer.getvalue()).decode("utf-8")
    except Exception as e:
        logger.error(f"Failed to fetch/convert image from URL: {e}")
        raise

def summarize_text_with_openai(text: str, level: str, api_key: str) -> str:
    """Summarize text using OpenAI API"""
    try:
        client = get_openai_client(api_key)
        if not client:
            raise Exception("OpenAI client not available")
        
        prompt = f"""Please provide a {level} summary of the following text for accessibility purposes. 
        Make it clear and easy to understand, focusing on the main points and key information.
        
        Text to summarize:
        {text[:4000]}"""  # Limit text length for API
        
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role": "system",
                    "content": "You are an accessibility assistant that creates clear, concise summaries of web content to help users with cognitive or reading difficulties."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            max_tokens=500 if level == "short" else 800
        )
        
        return response.choices[0].message.content
    except Exception as e:
        logger.error(f"OpenAI text summarization error: {e}")
        raise Exception(f"OpenAI API error: {str(e)}")

def summarize_text_simple(text: str, level: str) -> str:
    """Simple text summarization as fallback"""
    try:
        sentences = text.split('. ')
        if level == "short":
            # Take first 2-3 sentences
            summary_sentences = sentences[:3]
        else:
            # Take first 5-7 sentences
            summary_sentences = sentences[:7]
        
        summary = '. '.join(summary_sentences)
        if not summary.endswith('.'):
            summary += '.'
        
        return summary
    except Exception as e:
        logger.error(f"Simple summarization error: {e}")
        return "Unable to summarize text"

@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "message": "AccessAI API is running",
        "version": "1.0.0",
        "endpoints": [
            "/describe_image",
            "/summarize_text",
            "/voice_command",
            "/docs"
        ]
    }

@app.post("/describe_image", response_model=ImageDescriptionResponse)
async def describe_image(request: ImageDescriptionRequest):
    """Generate alt text description for an image"""
    try:
        description = None
        method = "tesseract"

        # Determine image data source
        image_data = request.image
        if (not image_data) and request.image_url:
            try:
                image_data = fetch_image_as_base64(request.image_url)
            except Exception as e:
                logger.warning(f"Image URL fetch failed: {e}")
        
        # Try OpenAI first if API key is provided
        if request.openai_key and image_data:
            try:
                description = describe_image_with_openai(image_data, request.openai_key)
                method = "openai"
            except Exception as e:
                logger.warning(f"OpenAI failed, falling back to Tesseract: {e}")
        
        # Fallback to Tesseract OCR
        if not description and image_data:
            description = describe_image_with_tesseract(image_data)
        elif not description:
            raise HTTPException(status_code=400, detail="No image data or image_url provided")
        
        return ImageDescriptionResponse(
            description=description,
            method=method
        )
    
    except Exception as e:
        logger.error(f"Image description error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/summarize_text", response_model=TextSummaryResponse)
async def summarize_text(request: TextSummaryRequest):
    """Summarize text content for accessibility"""
    try:
        summary = None
        
        # Try OpenAI first if API key is provided
        if request.openai_key:
            try:
                summary = summarize_text_with_openai(request.text, request.level, request.openai_key)
            except Exception as e:
                logger.warning(f"OpenAI failed, falling back to simple summarization: {e}")
        
        # Fallback to simple summarization
        if not summary:
            summary = summarize_text_simple(request.text, request.level)
        
        return TextSummaryResponse(
            summary=summary,
            original_length=len(request.text),
            summary_length=len(summary)
        )
    
    except Exception as e:
        logger.error(f"Text summarization error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/voice_command", response_model=VoiceCommandResponse)
async def process_voice_command(request: VoiceCommandRequest):
    """Process voice commands for navigation"""
    try:
        command = request.command.lower().strip()
        
        # Parse common voice commands
        if any(word in command for word in ['click', 'press', 'select']):
            # Extract number from command
            import re
            numbers = re.findall(r'\d+', command)
            if numbers:
                return VoiceCommandResponse(
                    action="click_element",
                    success=True,
                    message=f"Clicking element {numbers[0]}"
                )
        
        if any(word in command for word in ['scroll down', 'scroll down']):
            return VoiceCommandResponse(
                action="scroll_down",
                success=True,
                message="Scrolling down"
            )
        
        if 'scroll up' in command:
            return VoiceCommandResponse(
                action="scroll_up",
                success=True,
                message="Scrolling up"
            )
        
        if 'go back' in command:
            return VoiceCommandResponse(
                action="go_back",
                success=True,
                message="Going back"
            )
        
        if 'go forward' in command:
            return VoiceCommandResponse(
                action="go_forward",
                success=True,
                message="Going forward"
            )
        
        return VoiceCommandResponse(
            action="unknown",
            success=False,
            message="Command not recognized"
        )
    
    except Exception as e:
        logger.error(f"Voice command processing error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
