# AccessAI Chrome Extension

AI-powered accessibility enhancement for websites. AccessAI automatically generates alt text for images, summarizes page content, and provides voice navigation to make websites more accessible.

## Features

### 🖼️ Automatic Alt Text Generation
- Detects images without alt text
- Uses OpenAI Vision API or Tesseract OCR to generate descriptions
- Displays generated alt text as overlays on the page

### 📄 Text Summarization
- Extracts main content from web pages
- Generates simplified summaries using OpenAI GPT
- Configurable summary length (short/detailed)

### 🎤 Voice Navigation
- Numbers all interactive elements on the page
- Voice commands for navigation ("click 5", "scroll down", etc.)
- Text-to-speech feedback for actions

### ⚙️ Smart Settings
- Toggle features on/off
- Configure API endpoints
- Optional OpenAI API key for enhanced features

## Installation

### 1. Install the Backend API

```bash
cd backend
pip install -r requirements.txt
```

**Install Tesseract OCR:**
- **macOS**: `brew install tesseract`
- **Ubuntu/Debian**: `sudo apt-get install tesseract-ocr`
- **Windows**: Download from [GitHub](https://github.com/UB-Mannheim/tesseract/wiki)

**Start the backend server:**
```bash
python main.py
```

The API will be available at `http://localhost:8000`

### 2. Install the Chrome Extension

1. Open Chrome and go to `chrome://extensions/`
2. Enable "Developer mode" (toggle in top right)
3. Click "Load unpacked"
4. Select the `AccessAI` folder (containing `manifest.json`)
5. The AccessAI icon should appear in your Chrome toolbar

### 3. Configure the Extension

1. Click the AccessAI icon in your toolbar
2. Toggle on the features you want to use
3. Click "Settings" to configure:
   - API endpoint (default: `http://localhost:8000`)
   - OpenAI API key (optional, for enhanced features)
   - Summarization level

## Usage

### Basic Usage
1. Navigate to any website
2. Click the AccessAI icon
3. Toggle on desired features
4. Click "Analyze Current Page"

### Voice Navigation
1. Enable "Voice Navigation Mode"
2. Click "🎤 Start Voice" in the popup
3. Say commands like:
   - "Click 5" - clicks the 5th numbered element
   - "Scroll down" - scrolls down the page
   - "Go back" - goes back in browser history

### Features in Action

**Alt Text Generation:**
- Images without alt text will show loading indicators
- Generated descriptions appear as green overlays
- Alt text is automatically added to the image elements

**Text Summarization:**
- A summary panel appears in the top-right corner
- Shows simplified version of page content
- Auto-dismisses after 10 seconds

**Voice Navigation:**
- Interactive elements get numbered red circles
- Voice commands control page navigation
- Audio feedback confirms actions

## API Endpoints

The backend provides these endpoints:

- `GET /` - Health check
- `POST /describe_image` - Generate image descriptions
- `POST /summarize_text` - Summarize text content
- `POST /voice_command` - Process voice commands

See `backend/README.md` for detailed API documentation.

## Development

### Project Structure
```
AccessAI/
├── manifest.json          # Extension manifest
├── popup.html             # Extension popup UI
├── popup.css              # Popup styles
├── popup.js               # Popup logic
├── content.js             # Content script (runs on websites)
├── content.css            # Content script styles
├── background.js          # Background service worker
├── icons/                 # Extension icons
├── backend/               # FastAPI backend
│   ├── main.py           # API server
│   ├── requirements.txt  # Python dependencies
│   └── README.md         # Backend documentation
└── README.md             # This file
```

### Testing

1. Start the backend server: `cd backend && python main.py`
2. Load the extension in Chrome
3. Visit a news site (e.g., BBC, CNN, NYTimes)
4. Enable features and click "Analyze Current Page"
5. Test voice navigation with numbered elements

### Customization

**Adding New Voice Commands:**
Edit `content.js` in the `processVoiceCommand` method.

**Modifying AI Models:**
Edit `backend/main.py` to use different models or APIs.

**Styling:**
Modify `popup.css` and `content.css` for different appearances.

## Troubleshooting

### Extension Not Working
- Check that the backend server is running on `http://localhost:8000`
- Verify the extension is enabled in `chrome://extensions/`
- Check the browser console for errors

### API Errors
- Ensure Tesseract OCR is installed
- Check that the API endpoint is correct in settings
- For OpenAI features, verify your API key is valid

### Voice Recognition Issues
- Ensure microphone permissions are granted
- Check that the website supports the Web Speech API
- Try refreshing the page and re-enabling voice navigation

## Privacy & Security

- All processing happens locally or through your configured APIs
- No data is sent to third parties without your explicit configuration
- OpenAI API keys are stored locally in browser storage
- Image processing uses your local Tesseract installation as fallback

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review the browser console for errors
3. Ensure all dependencies are properly installed
4. Create an issue with detailed error information
