// Content script for AccessAI Chrome Extension

class AccessAIContent {
    constructor() {
        this.settings = {
            altTextEnabled: false,
            summarizeEnabled: false,
            voiceNavEnabled: false,
            summarizationLevel: 'short',
            apiEndpoint: 'http://localhost:8000',
            openaiKey: ''
        };
        
        this.voiceNavElements = [];
        this.voiceNavActive = false;
        this.elementCounter = 1;
        
        this.initialize();
    }

    async initialize() {
        // Load settings from storage
        await this.loadSettings();
        
        // Set up message listener
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            this.handleMessage(message, sender, sendResponse);
            return true; // Keep message channel open for async response
        });

        // Initialize features based on settings
        this.initializeFeatures();
        
        // Set up mutation observer for dynamic content
        this.setupMutationObserver();
    }

    async loadSettings() {
        try {
            const result = await chrome.storage.sync.get({
                altTextEnabled: false,
                summarizeEnabled: false,
                voiceNavEnabled: false,
                summarizationLevel: 'short',
                apiEndpoint: 'http://localhost:8000',
                openaiKey: ''
            });
            this.settings = result;
        } catch (error) {
            console.error('AccessAI: Error loading settings:', error);
        }
    }

    async handleMessage(message, sender, sendResponse) {
        try {
            switch (message.type) {
                case 'UPDATE_SETTINGS':
                    this.settings = message.settings;
                    this.initializeFeatures();
                    sendResponse({ success: true });
                    break;
                    
                case 'ANALYZE_PAGE':
                    await this.analyzePage();
                    sendResponse({ success: true });
                    break;
                    
                case 'VOICE_COMMAND':
                    const result = await this.processVoiceCommand(message.command);
                    sendResponse({ success: result });
                    break;

                case 'VOICE_START':
                    // Refresh voice navigation targets right before listening
                    this.setupVoiceNavigation();
                    this.startVoiceRecognition();
                    sendResponse({ success: true });
                    break;

                case 'VOICE_STOP':
                    this.stopVoiceRecognition();
                    sendResponse({ success: true });
                    break;
                    
                default:
                    sendResponse({ success: false, error: 'Unknown message type' });
            }
        } catch (error) {
            console.error('AccessAI: Error handling message:', error);
            sendResponse({ success: false, error: error.message });
        }
    }

    initializeFeatures() {
        // Clear existing features
        this.clearFeatures();
        
        if (this.settings.altTextEnabled) {
            this.enableAltTextGeneration();
        }
        
        if (this.settings.summarizeEnabled) {
            this.enableTextSummarization();
        }
        
        if (this.settings.voiceNavEnabled) {
            this.enableVoiceNavigation();
            this.injectVoiceControlsOverlay();
        }
    }

    clearFeatures() {
        // Remove existing overlays and indicators
        document.querySelectorAll('.accessai-overlay').forEach(el => el.remove());
        document.querySelectorAll('.accessai-indicator').forEach(el => el.remove());
        this.voiceNavElements = [];
        this.voiceNavActive = false;
    }

    injectVoiceControlsOverlay() {
        // Avoid duplicate
        if (document.querySelector('.accessai-voice-overlay')) return;

        const overlay = document.createElement('div');
        overlay.className = 'accessai-voice-overlay';
        overlay.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 10000;
        `;

        const button = document.createElement('button');
        button.textContent = '🎤 Start Listening';
        button.style.cssText = `
            background: #1976d2;
            color: #fff;
            border: none;
            border-radius: 24px;
            padding: 10px 16px;
            font-size: 14px;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        `;

        button.addEventListener('click', () => {
            if (this.voiceNavActive) {
                this.stopVoiceRecognition();
                button.textContent = '🎤 Start Listening';
                button.style.background = '#1976d2';
            } else {
                this.startVoiceRecognition();
                button.textContent = '🛑 Stop Listening';
                button.style.background = '#d32f2f';
            }
        });

        overlay.appendChild(button);
        document.body.appendChild(overlay);
    }

    async analyzePage() {
        try {
            if (this.settings.altTextEnabled) {
                await this.processImages();
            }
            
            if (this.settings.summarizeEnabled) {
                await this.processTextContent();
            }
            
            if (this.settings.voiceNavEnabled) {
                this.setupVoiceNavigation();
            }
        } catch (error) {
            console.error('AccessAI: Error analyzing page:', error);
        }
    }

    async processImages() {
        const images = document.querySelectorAll('img:not([alt]):not([aria-label])');
        
        for (const img of images) {
            try {
                // Skip very small images (likely decorative)
                if (img.naturalWidth < 50 || img.naturalHeight < 50) {
                    continue;
                }
                
                // Add loading indicator
                this.addLoadingIndicator(img);
                
                // Get image description
                const description = await this.getImageDescription(img);
                
                if (description) {
                    img.setAttribute('alt', description);
                    img.setAttribute('aria-label', description);
                    this.addAltTextOverlay(img, description);
                }
                
                // Remove loading indicator
                this.removeLoadingIndicator(img);
            } catch (error) {
                console.error('AccessAI: Error processing image:', error);
                this.removeLoadingIndicator(img);
            }
        }
    }

    async getImageDescription(img) {
        try {
            // Try canvas conversion, which may fail due to CORS tainting
            let base64 = null;
            try {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                canvas.width = img.naturalWidth;
                canvas.height = img.naturalHeight;
                ctx.drawImage(img, 0, 0);
                base64 = canvas.toDataURL('image/jpeg', 0.8);
            } catch (canvasError) {
                // Ignore; will fallback to URL-based processing
            }

            const payload = {
                image: base64 || undefined,
                image_url: (!base64 && img.src ? img.src : undefined),
                openai_key: this.settings.openaiKey
            };

            const response = await fetch(`${this.settings.apiEndpoint}/describe_image`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data.description;
        } catch (error) {
            console.error('AccessAI: Error getting image description:', error);
            return 'Image description unavailable';
        }
    }

    addLoadingIndicator(img) {
        const indicator = document.createElement('div');
        indicator.className = 'accessai-indicator loading';
        indicator.textContent = '🔄 Generating alt text...';
        indicator.style.cssText = `
            position: absolute;
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 12px;
            z-index: 10000;
            pointer-events: none;
        `;
        
        const rect = img.getBoundingClientRect();
        indicator.style.left = `${rect.left}px`;
        indicator.style.top = `${rect.top}px`;
        
        document.body.appendChild(indicator);
    }

    removeLoadingIndicator(img) {
        const indicator = document.querySelector('.accessai-indicator.loading');
        if (indicator) {
            indicator.remove();
        }
    }

    addAltTextOverlay(img, description) {
        const overlay = document.createElement('div');
        overlay.className = 'accessai-overlay alt-text';
        overlay.innerHTML = `
            <div class="accessai-tooltip">
                <strong>Generated Alt Text:</strong><br>
                ${description}
            </div>
        `;
        
        overlay.style.cssText = `
            position: absolute;
            background: rgba(76, 175, 80, 0.9);
            color: white;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 12px;
            z-index: 10000;
            max-width: 300px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
            pointer-events: none;
        `;
        
        const rect = img.getBoundingClientRect();
        overlay.style.left = `${rect.right + 10}px`;
        overlay.style.top = `${rect.top}px`;
        
        document.body.appendChild(overlay);
        
        // Auto-remove after 5 seconds
        setTimeout(() => overlay.remove(), 5000);
    }

    async processTextContent() {
        const mainContent = this.extractMainContent();
        if (!mainContent || mainContent.length < 100) {
            return;
        }
        
        try {
            const summary = await this.getTextSummary(mainContent);
            if (summary) {
                this.displaySummary(summary);
            }
        } catch (error) {
            console.error('AccessAI: Error processing text content:', error);
        }
    }

    extractMainContent() {
        // Try to find main content areas
        const selectors = [
            'main',
            'article',
            '[role="main"]',
            '.content',
            '.main-content',
            '#content',
            '#main'
        ];
        
        for (const selector of selectors) {
            const element = document.querySelector(selector);
            if (element) {
                return element.innerText;
            }
        }
        
        // Fallback to body text
        return document.body.innerText;
    }

    async getTextSummary(text) {
        try {
            const response = await fetch(`${this.settings.apiEndpoint}/summarize_text`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    text: text,
                    level: this.settings.summarizationLevel,
                    openai_key: this.settings.openaiKey
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            return data.summary;
        } catch (error) {
            console.error('AccessAI: Error getting text summary:', error);
            return null;
        }
    }

    displaySummary(summary) {
        const overlay = document.createElement('div');
        overlay.className = 'accessai-overlay summary';
        overlay.innerHTML = `
            <div class="accessai-summary">
                <h3>📄 Page Summary</h3>
                <p>${summary}</p>
                <button class="accessai-close">×</button>
            </div>
        `;
        
        overlay.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            color: #333;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            z-index: 10000;
            max-width: 400px;
            max-height: 300px;
            overflow-y: auto;
        `;
        
        // Add close button functionality
        const closeBtn = overlay.querySelector('.accessai-close');
        closeBtn.style.cssText = `
            position: absolute;
            top: 10px;
            right: 15px;
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #666;
        `;
        
        closeBtn.addEventListener('click', () => overlay.remove());
        
        document.body.appendChild(overlay);
        
        // Auto-remove after 10 seconds
        setTimeout(() => overlay.remove(), 10000);
    }

    enableVoiceNavigation() {
        this.setupVoiceNavigation();
    }

    setupVoiceNavigation() {
        // Find all interactive elements
        const interactiveElements = document.querySelectorAll(
            'a, button, input, select, textarea, [role="button"], [role="link"], [tabindex]'
        );
        
        this.voiceNavElements = Array.from(interactiveElements).filter(el => {
            const rect = el.getBoundingClientRect();
            return rect.width > 0 && rect.height > 0 && this.isElementVisible(el);
        });
        
        this.addVoiceNavIndicators();
    }

    isElementVisible(element) {
        const style = window.getComputedStyle(element);
        return style.display !== 'none' && 
               style.visibility !== 'hidden' && 
               style.opacity !== '0';
    }

    addVoiceNavIndicators() {
        this.voiceNavElements.forEach((element, index) => {
            const indicator = document.createElement('div');
            indicator.className = 'accessai-indicator voice-nav';
            indicator.textContent = index + 1;
            indicator.dataset.elementIndex = index;
            
            indicator.style.cssText = `
                position: absolute;
                background: #ff6b6b;
                color: white;
                width: 24px;
                height: 24px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 12px;
                font-weight: bold;
                z-index: 10000;
                pointer-events: none;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
            `;
            
            const rect = element.getBoundingClientRect();
            indicator.style.left = `${rect.left - 12}px`;
            indicator.style.top = `${rect.top - 12}px`;
            
            document.body.appendChild(indicator);
        });
    }

    async processVoiceCommand(command) {
        try {
            // Parse voice commands
            const wordToNum = {
                'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4,
                'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9,
                'ten': 10, 'eleven': 11, 'twelve': 12, 'thirteen': 13,
                'fourteen': 14, 'fifteen': 15, 'sixteen': 16, 'seventeen': 17,
                'eighteen': 18, 'nineteen': 19, 'twenty': 20
            };
            let numberMatch = command.match(/(\d+)/);
            if (!numberMatch) {
                // Try basic word numbers
                const tokens = command.split(/\s+/);
                for (const t of tokens) {
                    if (wordToNum[t] !== undefined) {
                        numberMatch = [String(wordToNum[t]), String(wordToNum[t])];
                        break;
                    }
                }
            }
            if (numberMatch) {
                const chosenNumber = parseInt(numberMatch[1]);
                const elementIndex = chosenNumber - 1;
                if (elementIndex >= 0 && elementIndex < this.voiceNavElements.length) {
                    const element = this.voiceNavElements[elementIndex];
                    element.click();
                    this.speak(`Clicked element ${chosenNumber}`);
                    return true;
                } else {
                    this.speak(`Element ${chosenNumber} not found`);
                    return false;
                }
            }
            
            // Handle other voice commands
            if (command.includes('scroll down')) {
                window.scrollBy(0, 300);
                this.speak('Scrolled down');
                return true;
            }
            
            if (command.includes('scroll up')) {
                window.scrollBy(0, -300);
                this.speak('Scrolled up');
                return true;
            }
            
            if (command.includes('go back')) {
                window.history.back();
                this.speak('Going back');
                return true;
            }
            
            if (command.includes('go forward')) {
                window.history.forward();
                this.speak('Going forward');
                return true;
            }
            
            this.speak('Command not recognized');
            return false;
        } catch (error) {
            console.error('AccessAI: Error processing voice command:', error);
            return false;
        }
    }

    speak(text) {
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.rate = 0.9;
            utterance.pitch = 1;
            speechSynthesis.speak(utterance);
        }
    }

    // Voice recognition now runs in the page context for proper mic permissions
    startVoiceRecognition() {
        try {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            if (!SpeechRecognition) {
                this.speak('Voice recognition not supported in this browser');
                return;
            }

            if (this.recognition) {
                this.stopVoiceRecognition();
            }

            this.recognition = new SpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            this.recognition.onstart = () => {
                this.voiceNavActive = true;
                this.speak('Listening');
            };

            this.recognition.onresult = async (event) => {
                const command = event.results[0][0].transcript.toLowerCase().trim();
                await this.processVoiceCommand(command);
            };

            this.recognition.onerror = (event) => {
                if (event.error === 'not-allowed' || event.error === 'permission-denied') {
                    this.speak('Microphone permission denied. Allow microphone in site permissions.');
                } else if (event.error === 'no-speech') {
                    this.speak('No speech detected.');
                } else if (event.error === 'audio-capture') {
                    this.speak('No microphone found.');
                }
                this.stopVoiceRecognition();
            };

            this.recognition.onend = () => {
                this.stopVoiceRecognition();
            };

            this.recognition.start();
        } catch (error) {
            console.error('AccessAI: Error starting voice recognition:', error);
            this.speak('Unable to start voice recognition');
        }
    }

    stopVoiceRecognition() {
        try {
            if (this.recognition) {
                this.recognition.onstart = null;
                this.recognition.onresult = null;
                this.recognition.onerror = null;
                this.recognition.onend = null;
                this.recognition.stop();
                this.recognition = null;
            }
            this.voiceNavActive = false;
        } catch (error) {
            console.error('AccessAI: Error stopping voice recognition:', error);
        }
    }

    setupMutationObserver() {
        const observer = new MutationObserver((mutations) => {
            let shouldReanalyze = false;
            
            mutations.forEach((mutation) => {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    shouldReanalyze = true;
                }
            });
            
            if (shouldReanalyze) {
                // Debounce reanalysis
                clearTimeout(this.reanalysisTimeout);
                this.reanalysisTimeout = setTimeout(() => {
                    this.initializeFeatures();
                }, 1000);
            }
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }
}

// Initialize content script
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        new AccessAIContent();
    });
} else {
    new AccessAIContent();
}
